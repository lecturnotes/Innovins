::Documentation on Task Project Work::
---------------------------------------------
EXPLANATION FOR TASK 1 AND 2::-
---------------------------------
1.inside the folder put the folder named->innovins_interview, in htdocs e.g //localhost/innovins_interview->it will redirect to login page and new user can register, which is also gives the functionality of create user(CRUD of user)

Import the database in localhost, the sql file inside the main folder.(table name is:users)for task 1 & 2

2. After login it will rediret to user list page(manage user).

3. Authentiction is given as, if the logged in user is admin,then that user can edit and delete the userdetails of all but if user type is =user then it can edit its detail only.

4.reset password functionality-on clicking reset password , give email id then mail will be sent with code=1111 to given email id, a link for reseting password. on clicking that link  reset_password file will open . user can set new password.

N:B--Now mail is not going in localhost due to some sort of configuration, once it will set up in server, mail will be sent...till that the reset password link is:http://localhost/innovins_interview/reset_password.php

5.Proper session management is done with logout option.

6.For testing purpose I have created the users, use the user_name(as in database) and password(1111 for all users) to login else create new.
---------------------------------------------------------------------------------------------------------------

EXPLANATION FOR TASK 3(API)::-

1. (table name is:products)for task 3 and inside 'innovins_interview' folder API folder is there,insite that api.php is the code file.

2. APIs created for product management(post,update,patch,put,delete) and tested in postman.

3. The tested results screenshots of POSTMAN also there in API folder(innovins_interview->API->screenshots_postman).
---------------------------------------------------------------------------------------------------------------

N:B--FOR ANY FUNCTIONALITY RELATED DOUBTS, KINDLY CONTACT ME IN MY PHONE NO.


