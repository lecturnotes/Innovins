<?php
    include("includes/connection.php");
   

    $return_url = "index.php";

    if (isset($_GET['code']) && $_GET['code']!="") {
    	$code = secure_inputs($_GET['code']);
    	$user = query_data("select * from users where verify_code='$code'");

    }
    if($code!='' && $user) {
	    //if ($_POST) {  
	    if ($_POST && $_POST['csrf']== $_SESSION["token"]) {

	    	$_SESSION['token'] = md5(uniqid(rand(), TRUE));  
	    	if($_POST['new_pwd'] == $_POST['c_pwd']){
	    		$upd['password']= $new_pwd = md5($_POST['new_pwd']);
				$upd['verify_code']= '';
	        	$updatechk = update_data("users", $upd, array('id'=>$user[0]->id));
	        	if ($updatechk) {
					

				} else {
					$msg = "Error occurred. Please try again.";
				    setcookie("error", $msg, time() + 3);
				    header("location:reset_password.php?code=".$code);
				}
			} else {
				$msg = "Confirm password doesn't match!";
			    setcookie("error", $msg, time() + 3);
			    header("location:reset_password.php?code=".$code);
			}
        } 
	} else {
     	$msg = "User does not exists.";            
        setcookie("msg", $msg, time() + 3);
        header("location:forgot_password.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>INNOVINS - Reset Password</title>
		<link rel="shortcut icon" type="image/x-icon" href="<?=SITEURL?>assets/img/favicon.png">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/feather.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/style.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/custom.css">
		<style>
			.login-wrapper .loginbox {border: 1px solid #e5e5e5; border-radius: 5px; -webkit-box-shadow: 0 10px 15px #e5e5e5; box-shadow: 0 10px 15px #e5e5e5;}
		</style>
	</head>
	<body>
		<div class="main-wrapper">
			<div class="header d-none">
				<ul class="nav nav-tabs user-menu">
					<li class="nav-item">
						<a href="#" id="dark-mode-toggle" class="dark-mode-toggle"><i class="feather-sun light-mode"></i><i class="feather-moon dark-mode"></i></a>
					</li>
				</ul>
			</div>
			<div class="row">
				
				<div class="col-md-12 login-wrap-bg">
					<div class="login-wrapper">
						<div class="loginbox">
							<div class="img-logo">
								<img src="<?=SITEURL?>assets/img/logo_big.png" class="img-fluid" alt="Logo">
							</div>
							<!--<h3>Aspire Hospital</h3>-->
							<p class="account-subtitle">We will send new password to your email id.</p>
							<?php if (isset($_COOKIE['msg'])) { ?><center><span style="color:red;"><?php print str_replace("+", " ", $_COOKIE['msg']); ?></span></center><?php } ?>
							<?php if (isset($_COOKIE['error'])) { ?><center><span style="color:red;"><?php print str_replace("+", " ", $_COOKIE['error']); ?></span></center><?php } ?>
							<?php if (isset($_COOKIE['success'])) { ?><center><span style="color:green;"><?php print str_replace("+", " ", $_COOKIE['success']); ?></span></center><?php } ?>
							<form method="post">
								<div class="form-group form-focus">
									<input type="password" class="form-control floating" name="new_pwd">
									<label class="focus-label">Enter New Password</label>
								</div>
								<div class="form-group form-focus">
									<input type="password" class="form-control floating" name="c_pwd">
									<label class="focus-label">Confirm Your Password</label>
								</div>
								<div class="d-grid">
									<input type="hidden" name="csrf" value="<?=$_SESSION["token"];?>">
									<button class="btn btn-login" type="submit">Submit</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- JS -->
		<script src="<?=SITEURL?>assets/js/jquery-3.6.0.min.js"></script>
		<script src="<?=SITEURL?>assets/js/bootstrap.bundle.min.js"></script>
		<script src="<?=SITEURL?>assets/js/script.js"></script>
	</body>
</html>