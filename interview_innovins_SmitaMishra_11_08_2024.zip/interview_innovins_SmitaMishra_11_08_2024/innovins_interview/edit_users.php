<?php 
	include("includes/connection.php");
    

//     ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

	$page_name = 'Manage Users';
	$page_title = 'Manage Users';
	$return_url = 'edit_users.php';

	

	if (isset($_POST['update-users']) && $_POST['csrf']== $_SESSION["token"]) {
    	$_SESSION['token'] = md5(uniqid(rand(), TRUE));

		$data['user_name'] = $u_nm = secure_inputs($_POST['user_name']);
		$data['full_name'] = $_POST['full_name'];
		$data['phone'] = $_POST['phone'];
		$data['email'] = $_POST['email'];
		$data['user_type'] = $_POST['user_type'];
		

		

		/* Get user details For respective id*/
		if (isset($_GET['id']) && $_GET['id'] !='') {
			$id = secure_inputs($_GET['id']);

			$chk = query_data("SELECT * FROM users where user_name='$u_nm' AND id!='$id'");

			if ($chk) {
				$msg = "User already exists.";
			    setcookie("error", $msg, time() + 3);
			    header("location:".$return_url);
			} else {
				$updatechk = update_data('users',$data, array('id'=>$id));
			    $last_id = $id;

			    if($last_id!=0) {
					
					if ($updatechk['affectrow'] > 0) {
						$msg = $updatechk['message'];
					    setcookie("success", $msg, time() + 3);
					   	header("location:".$return_url."?id=".$id);
					} else {
						$msg = $updatechk['message'];
						$msg = 'Data Processed successfully.';
					    setcookie("success", $msg, time() + 3);
					   header("location:".$return_url."?id=".$id);
					}
				}
			}
		}
    }

	/* Get user details For respective id*/
	if (isset($_GET['id']) && $_GET['id'] !='') {
		$id = secure_inputs($_GET['id']);

		//echo "SELECT * FROM users WHERE id=".$id;exit;
		$row = query_data("SELECT * FROM users WHERE id=".$id);
		

		if (!empty($row)) {
			$r = $row[0];
		} else {
			header("location:users_listing.php");
		}

		
	} else {
    	header("location:users_listing.php");
    }



	include("inc/top_head.php");
 
?>
<style type="text/css">
	.remove {
	    padding: 2px;
	    margin-left: 183px;
	    border: 1px solid #dda5a5;
	}
</style>
	
<?php if (isset($_COOKIE['success'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-success">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['success']); ?>
	</div>
<?php } ?>
<?php if (isset($_COOKIE['error'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-danger">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['error']); ?>
	</div>
<?php } ?>

<form method="post">
	<div class="row">	
		<div class="col-sm-12">
			<div class="card">
				<div class="card-header">
					<div class="row mb-2 mt-2"> <!-- align-items-center -->
						<div class="col-md-4">
							<div class="row mb-2">
								<div class="col-3"><label>Full Name<span class="text-danger">*</span></label></div>
								<div class="col-8"  style="min-width: 250px;">
									<input type="text" class="form-control" name="full_name"  required autocomplete="off" value="<?=(isset($r) && $r->full_name!="" ? $r->full_name : "")?>" maxlength="30" autofocus="autofocus">
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>Phone</label></div>				
								<div class="col-8" style="min-width: 250px;">			
									<input type="text" class="form-control" name="phone" id="phone" autocomplete="off" onkeypress="return /[0-9]/i.test(event.key)" value="<?=(isset($r) && $r->phone!="" ? $r->phone : "")?>" maxlength="10">
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>Email</label></div>				
								<div class="col-8" style="min-width: 250px;">			
									<input type="email" class="form-control" name="email" id="email" autocomplete="off" value="<?=(isset($r) && $r->email!="" ? $r->email : "")?>" maxlength="50">
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row mb-2">
								<div class="col-3"><label>User Type<span class="text-danger">*</span></label></div>		
								<div class="col-8" style="min-width: 250px;">			
									<select class="form-select" name="user_type" required>
										<option value="">Select...</option>
										<option value="Admin" <?=(isset($r) && $r->user_type=="Admin" ? "selected" : "")?>>Admin</option>
										<option value="User" <?=(isset($r) && $r->user_type=="User" ? "selected" : "")?>>User</option>
										
									</select>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>User Name<span class="text-danger">*</span></label></div>
								<div class="col-8"  style="min-width: 250px;">
									<input type="text" class="form-control" name="user_name"  required autocomplete="off" value="<?=(isset($r) && $r->user_name!="" ? $r->user_name : "")?>" maxlength="20">
								</div>
							</div>
							
						</div>
						
					</div>	
				</div>
				<div class="card-body">							
					
					<div class="col-md-12">
						<div  style="text-align:center" class="">
							<input type="hidden" name="csrf" value="<?=$_SESSION["token"]?>">
							<button type="submit" class="btn btn-login" name="update-users">Save</button>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
</form>


</div> 
</div>	
</div>



<?php include("inc/js.php"); ?>

<script type="text/javascript">

	function checkAll(i) {
		var mod_id = $('#mst_mod_chk'+i).is(':checked');

		if (mod_id==true) {
			$('.mod-control-input'+i).prop('checked', true);
			$('#mst_view'+i).val(1);
			$('#mst_edit'+i).val(1);
			$('#mst_del'+i).val(1);
		} else {
			$('#mst_view'+i).val(0);
			$('#mst_edit'+i).val(0);
			$('#mst_del'+i).val(0);
			$('.mod-control-input'+i).prop('checked', false);
		}
	}
</script>
</body>
</html>