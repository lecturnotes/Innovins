<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?=(isset($page_title))?$page_title:'INNOVINS' ?></title>
		<link rel="shortcut icon" href="http://localhost/innovins_interview/assets/img/favicon.png">
		<?php  include ("css.php"); ?>	
		
	</head>
	<body>
		<div class="main-wrapper">
			<?php include("header.php"); ?>
			<?php //include("sidebar.php"); ?>

				<div class="page-wrapper">
					<div class="content container-fluid">
						<div class="page-header">
							<div class="row">
								<div class="col">
									<h4 class="card-title"><?=(isset($page_title) ? $page_title : '')?></h4>
								</div>
								<div class="col-auto">
									<?php include("top_menu.php"); ?>
								</div>
							</div>
						</div>	
			