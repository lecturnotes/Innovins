<script src="http://localhost/innovins_interview/assets/js/jquery-3.6.0.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.6.0.js"></script> -->
<!-- <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script> -->
<script src="http://localhost/innovins_interview/assets/js/jquery-ui.js"></script>
<script src="http://localhost/innovins_interview/assets/js/bootstrap.min.js"></script>
<script src="http://localhost/innovins_interview/assets/js/bootstrap.bundle.min.js"></script>
<script src="http://localhost/innovins_interview/assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="http://localhost/innovins_interview/assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="http://localhost/innovins_interview/assets/plugins/datatables/datatables.min.js"></script>
<script src="http://localhost/innovins_interview/assets/plugins/select2/js/select2.min.js"></script>
<script src="http://localhost/innovins_interview/assets/js/moment.min.js"></script>
<script src="http://localhost/innovins_interview/assets/plugins/daterangepicker/daterangepicker.js"></script>
<!-- <script src="http://localhost/innovins_interview/assets/js/aa11bf52c3.js"></script> -->
<script src="http://localhost/innovins_interview/assets/plugins/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script src="http://localhost/innovins_interview/assets/js/autocomplete.js"></script>

<script src="http://localhost/innovins_interview/assets/js/sweetalert2.js"></script>
<script src="http://localhost/innovins_interview/assets/js/script.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/js/standalone/selectize.js"></script>

<!--added js for datatable file formats..............by smita-------------09/03/2023-----------start---->
<script src="http://localhost/innovins_interview/assets/datatablejs/buttons.print.min.js"></script>
<script src="http://localhost/innovins_interview/assets/datatablejs/pdfmake.min.js"></script>
<script src="http://localhost/innovins_interview/assets/datatablejs/buttons.flash.min.js"></script>
<script src="http://localhost/innovins_interview/assets/datatablejs/dataTables.buttons.min.js"></script>
<script src="http://localhost/innovins_interview/assets/datatablejs/buttons.html5.min.js"></script>


<!--CDN..S..................................-->
<!-- <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script> -->

<!--added js for datatable file formats..............by smita-------------09/03/2023-----------end---->

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script> -->

