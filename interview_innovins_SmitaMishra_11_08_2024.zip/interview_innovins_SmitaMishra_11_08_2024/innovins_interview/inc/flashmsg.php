<?php if (isset($_COOKIE['success'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-success">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['success']); ?>
	</div>
<?php } ?>
<?php if (isset($_COOKIE['error'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-danger">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['error']); ?>
	</div>
<?php } ?>