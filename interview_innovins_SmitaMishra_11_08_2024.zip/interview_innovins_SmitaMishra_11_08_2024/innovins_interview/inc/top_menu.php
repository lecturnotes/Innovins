<?php 
	//include("includes/connection.php");
	?>

<a class="dropdown-item" href="http://localhost/innovins_interview/logout.php"><i class="feather-log-out me-1"></i> Logout</a>