<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/bootstrap.min.css">
<!-- <link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/layout.css"> -->
<!-- <link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/font-awesome.min.css">  --> 
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/fontawesome/css/all.min.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/datatables/datatables.min.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/select2/css/select2.min.css" />
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/feather.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/style.css">	
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/custom.css">
<!-- <link rel="stylesheet" href="../assets/css/bootstrap-datepicker.min.css"> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css"> -->
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/jquery-ui.css">
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/plugins/datetimepicker/bootstrap-datetimepicker.css">
<!-- <link rel="stylesheet" href="http://localhost/innovins_interview/cropper/cropper.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/css/selectize.bootstrap4.css">

<!--added by smita on 10/03/2023-->
<link rel="stylesheet" href="http://localhost/innovins_interview/assets/datatablecss/buttons.dataTables.min.css">

<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"> -->

<style type="text/css">
	.close {
	    font-size: 1.35rem;
	    font-weight: 700;
	    line-height: 1;
	    float: right;
	    opacity: .5;
	    color: #000;
	    text-shadow: 0 1px 0 #fff;
	}
  .container-fluid{
    position: absolute;
    right: 108px;
  }

	.remove {
        position: absolute;
        z-index: 100;
        padding: 3px;
        color: #b31212;
        font-weight: bold;
        cursor: pointer;
        opacity: 1.2;
        text-align: center;
        font-size: 17px;
        line-height: 10px;
        border-radius: 50%;
        background-color: #FFF;
        margin-top: 22px;
    	margin-left: 133px;
    }
    .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 18px;
    }

    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 14px;
width: 14px;
left: 3px;
bottom: 2px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;
    }

    input:checked + .slider {
      background-color: #2196F3;
    }

    input:focus + .slider {
      box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
      -webkit-transform: translateX(20px);
      -ms-transform: translateX(20px);
      transform: translateX(20px);
    }

    /* Rounded sliders */
    .slider.round {
      border-radius: 34px;
    }

    .slider.round:before {
      border-radius: 50%;
    }
</style>