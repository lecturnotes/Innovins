<?php

    if(isset($_SESSION['user_id'])) {
    	$user_id = $_SESSION['user_id'];

    	$user = get_data("users",$user_id);
    }
?>

<div class="header">
	<div class="header-left">
		<a href="<?=SITEURL?>masters/index.php" class="logo"><img src="<?=SITEURL?>assets/img/logo_white.png" alt="Logo"></a>
		<a href="index.html" class="logo logo-small"><img src="<?=SITEURL?>assets/img/logo-small.png" alt="Logo" width="30" height="30"></a>
		<a href="javascript:void(0);" id="toggle_btn"><i class="feather-chevrons-left"></i></a>
	</div>
	<div class="top-nav-search">
		<div class="main">
			<h4 class="logotext">INNOVINS ADMIN PANEL</h4>
		</div>
	</div>

	<a class="mobile_btn" id="mobile_btn"><i class="fas fa-bars"></i></a>
	<ul class="nav nav-tabs user-menu">
		

		<li class="nav-item dropdown main-drop">
			
			<div class="dropdown-menu">
				<div class="user-header">
					<div class="avatar avatar-sm">
						<img src="http://localhost/innovins_interview/assets/img/no-Image.png" alt="User Image" class="avatar-img rounded-circle" height="32px">
					</div>
					<div class="user-text">
						<h6><?=(isset($user) && $user[0]->user_name!="" ? $user[0]->user_name : "" )?></h6>
						<p class="text-muted mb-0"><?=(isset($user) && $user[0]->user_type!="" ? $user[0]->user_type : "" )?></p>
					</div>
				</div>
				<a class="dropdown-item" href="http://localhost/innovins_interview/assets/change_password.php"><i class="feather-log-out me-1"></i> Change Password</a><hr>				
				<a class="dropdown-item" href="http://localhost/innovins_interview/assets/logout.php"><i class="feather-log-out me-1"></i> Logout</a>
			</div>
		</li>
	</ul>
</div>


