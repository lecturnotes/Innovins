<?php
	define('ADMINEMAIL', 'smitamishra979@gmail.com');
	date_default_timezone_set("Asia/Calcutta");



	require 'mailclass/Exception.php';
	require 'mailclass/PHPMailer.php';
	require 'mailclass/SMTP.php'; 

	

	



	function date_formats($in) {
		return date('d M Y',strtotime($in));
	}
	function datetime_formats($in) {
		return date('d M Y h:i A',strtotime($in));
	}
	function datetime_24formats($in) {
		return date('d M Y H:i A',strtotime($in));
	}

	function mycount($data){
	    $data = (array) $data;
	    return count($data);
	}



	function siteURL(){
	    $protocol = "http://";
	    
	    $domainName = 'innovins_interview/';
	    //return $protocol.$domainName;
	    return "http://".$domainName;
	}

	define('SITEURL', siteURL());

	function filter_inputs($data){
		$filter = trim(strip_tags($data));
		return $filter;
	}

	function filter_number($data){
	    $filter = preg_replace('/[^0-9]/', '', $data);
	    return $filter;
	}

	// function secure_inputs($data){
	// 	$connection = db_connect();
	// 	return mysqli_real_escape_string($connection, $data);
	// 	mysqli_close($connection);
	// }

	function secure_inputs($data){
		$connection = db_connect();
		$data = str_replace("'","&#39;", $data);
		//return mysqli_real_escape_string($connection, $data);
		return $data;
		mysqli_close($connection);
	}

	/* INSERT DATA */
	function insert_data($table, $data){
		$connection = db_connect();
		$fld = $val = '';
		$result = [];
		foreach($data as $f=>$v){			
			$fld .= $f.',';
			$value = secure_inputs($v);
			$val .= "'".$value."',";
		}
		$fld = rtrim($fld, ",");
		$val = rtrim($val, ",");
		$qry = "insert into $table ($fld) values($val)";
		
		$lastid = db_query_last_id($qry);

		if($lastid){
			$result['status'] =1;
			$result['insertid'] = $lastid;
			$result['message'] = "Record added successfully!";
		} else {
			$result['status'] =0;
			$result['insertid'] = 0;
			$result['message'] = "ERROR!! ".db_error();
		}	

		return $result;
	}

	/* INSERT MULTIPLE */

	

	/* UPDATE DATA */
	function update_data($table, $data, $criteria){ 
		//example update_data($table, array('name'=>'abc'), array('id'=>1))
		$connection = db_connect();
		$sval = '';
		$qry = '';
		$result = [];
		foreach($data as $k=>$v){
			$value = secure_inputs($v);
			$qry .= "`$k`='$value',";
		}
		$qry=rtrim($qry,",");
		$whr = '';
		foreach($criteria as $f=>$v){ 
			$v = secure_inputs($v);
			$whr .= "`$f`='$v' AND "; 
		} 
		$whr = rtrim($whr," AND ");
		$query = "update $table set $qry where $whr ";

		if(db_query($query)===TRUE){
			$affectrow = mysqli_affected_rows($connection);
			$result['status'] =1;
			$result['affectrow'] = $affectrow;
			if($affectrow >0){
				$result['message'] = "Record updated successfully!";
			} else {
				$result['message'] = "Nothing to Update!";
			}
		} else {
			$result['status'] =0;
			$result['affectrow'] = 0;
			$result['message'] = "ERROR!! ".db_error();
		}

		return $result;
	}

	/* DELETE DATA */
	function delete_data($table, $id){
		//delete_data($table, array('id'=>1,'name'=>'abc');	
		$connection = db_connect();
		$result = [];
		if(is_array($id)){
			$qry = "delete from $table where ";
			foreach($id as $k=>$v){
				$v = secure_inputs($v);
				$qry.=" `$k`='$v' and";
			}
			$qry = rtrim($qry, "and");
			
		} else {
			$id = filter_number($id);
			$qry = 'delete from '.$table.' where id='.$id;
		}
		
		if(db_query($qry)===TRUE){
			$affectrow = mysqli_affected_rows($connection);
			$result['status'] =1;
			$result['affectrow'] = $affectrow;
			if($affectrow >0){
				$result['message'] = "Record deleted successfully!";
			} else {
				$result['message'] = "Nothing found to delete!";
			}
		} else {
			$result['status'] =0;
			$result['affectrow'] = 0;
			$result['message'] = "ERROR!! ".db_error();
		}

		return $result;
	}

	/* NUMBER OF ROWS */
	function number_rows($table, $field=null, $value=null){ 
		//number_rows($table, array(field), array($value)) or 
		//number_rows($table, array(field1, field2), array(value1, value2)
		$connection = db_connect();
		if(is_array($field) && is_array($value)){
			$q = "select * from $table where ";
			$i=0;
			foreach($field as $f){
				$v = $value[$i++];
				$q.=" $f='".$v."' and";
			}
			$q = rtrim($q, 'and');
			
		} else {
			if($field==null && $value==null)
				$q = "select * from $table";
			else
				$q = "select * from ".$table." where ".$field."='".$value."'";
		}

		$query	= db_query($q);
		$result = mysqli_num_rows($query);
		if($result) {
			return $result;
		} else {
			return 'invalid';
		}
	}

	/* GET DATA */
	function get_data($table, $id=null, $distinct=null, $order=null){
		$connection = db_connect();
		$id = filter_number($id);
		$row= array();
		if($id != null)
			$q = 'select * from '.$table.' where id='.$id;
		else if($distinct != null)
			$q = "select DISTINCT $distinct from $table";
		else if($order !=null)
			$q = 'select * from '.$table.' order by id '.$order;
		else	
			$q = 'select * from '.$table.' order by id desc';
		$qry = db_query($q);
		
		for ($res = array(); $tmp = $qry->fetch_array(MYSQLI_ASSOC);) $res[] = (object)$tmp;

		return $res;			
	}

	/* GET DATA BY */
	function query_data($query, $type='obj', $len='M') {
		$connection = db_connect();
		
		$qry = db_query($query);
		if($type=='array'){
			for ($res = array(); $tmp = $qry->fetch_array(MYSQLI_ASSOC);) $res[] = $tmp; 
		} else {
			for ($res = array(); $tmp = $qry->fetch_array(MYSQLI_ASSOC);) $res[] = (object)$tmp;
		}
		
		if(!empty($res)){
			if($len=='S'){
				return $res[0];
			} else {
				return $res;
			}
		} else {
			return array();
		}
	}

	/* PRINT RESULT IN ARRAY */
	function print_result($data){
		echo '<pre>';
		print_r($data);
		echo '</pre>';
	}

	/* Count Array data */
	function count_data($data){
		$data = (array) $data;
		return count($data);
	}

	function json_export($data){
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);
		exit;
	}


	
	function removeSpchar($str){
	    $str = str_replace("%", "-", $str);
	    $str = str_replace("#", "-", $str);
	    $str = str_replace("!", "-", $str);
	    $str = str_replace("@", "-", $str);
	    $str = str_replace("^", "-", $str);
	    $str = str_replace("*", "-", $str);
	    $str = preg_replace('/\s\&+/', '-', $str);
	    $str = preg_replace("/\s/", "-", $str);
	    $str = preg_replace('/\-\-+/', '-', $str);
	    $str = str_replace("(", "-", $str);
	    $str = str_replace(")", "-", $str);
	    $str = str_replace("(", "-", $str);
	    $str = str_replace(")", "_", $str);
	    $str = str_replace("_", "-", $str);
	    $str = str_replace("&", "-", $str);
	    $str = str_replace("'", "-", $str);
		$str = str_replace(",", "-", $str);
		// $str = str_replace(".", "-", $str);
	    $str = preg_replace('/\-\-+/', '-', $str);
	    $str = rtrim($str, '-');
	    return $str;
	}

	function addhttp($url) {
		if($url){
		    if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
		        $url = "http://" . $url;
		    }
		    return $url;
		}
	}

	
	
	

	

	if (!isset($_SESSION['token'])){
	    $token = md5(uniqid(rand(), TRUE));
	    $_SESSION['token'] = $token;
	    $_SESSION['token_time'] = time();
	} else {
	    $token = $_SESSION['token'];
	}

	function encryptIt($q){
	    $secret_key = 'Life is a long lesson';
	    $secret_iv = 'Keep_smiling';
	    $output = false;
	    $encrypt_method = "AES-256-CBC";
	    $key = hash( 'sha256', $secret_key );
	    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
	    $qEncoded = base64_encode(openssl_encrypt($q, $encrypt_method, $key, 0, $iv));
	    return($qEncoded);
	}

	function decryptIt($q){
	    $secret_key = 'Life is a long lesson';
	    $secret_iv = 'Keep_smiling';
	    $output = false;
	    $encrypt_method = "AES-256-CBC";
	    $key = hash( 'sha256', $secret_key );
	    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
		$qDecoded = openssl_decrypt(base64_decode($q),$encrypt_method, $key, 0, $iv);
	    return($qDecoded);
	}


	
	function changeURL($str) {
	    $str = str_replace("%", "-", $str);
	    $str = str_replace("#", "-", $str);
	    $str = str_replace("!", "-", $str);
	    $str = str_replace("@", "-", $str);
	    $str = str_replace("^", "-", $str);
	    $str = str_replace("*", "-", $str);
	    $str = preg_replace('/\s\&+/', '-', $str);
	    $str = preg_replace("/\s/", "-", $str);
	    $str = preg_replace('/\-\-+/', '-', $str);
	    $str = str_replace("(", "-", $str);
	    $str = str_replace(")", "-", $str);
	    $str = str_replace("(", "-", $str);
	    $str = str_replace(")", "_", $str);
	    $str = str_replace("_", "-", $str);
	    $str = str_replace("&", "-", $str);
	    $str = str_replace("'", "-", $str);
	    $str = str_replace(":", "-", $str);
	    $str = preg_replace('/\-\-+/', '-', $str);
	    $str = rtrim(strtolower($str), '');
	    return $str;
	}
?>