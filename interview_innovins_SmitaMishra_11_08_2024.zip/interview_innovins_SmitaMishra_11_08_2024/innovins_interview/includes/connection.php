<?php
    ini_set('session.gc_maxlifetime', 3600);
    session_set_cookie_params(3600);



    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    //error_reporting(E_ALL);
error_reporting(0);
    
    session_start();
    global $connection;
    function db_connect() {
        static $connection;
    	$username	= "root"; 
    	$password	= ""; 
    	$dbname		= "innovins_task"; 
    	$host		= "localhost";

        if(!isset($connection)) { 
            $connection = mysqli_connect($host,$username,$password,$dbname);
        }
        if($connection === false) {
            return mysqli_connect_error(); 
        }
        return $connection;
    }

    function db_query($query) {
        $connection = db_connect();
        $result = mysqli_query($connection,$query);
        //print_result($result);exit;
        return $result;
    }
    function db_query_last_id($query) {
        $connection = db_connect();
        $result = mysqli_query($connection,$query);
        $last_id = mysqli_insert_id($connection);
        return $last_id;
    }

    function db_error() {
        $connection = db_connect();
        return mysqli_error($connection);
    }

    function db_close(){
    	$connection = db_connect();
    	mysqli_close($connection);
    }

    $connect = db_connect();

    @session_start();
    set_time_limit(0);

    include 'functions.php';
?>