<?php
    //include("includes/connection.php");
    //session_destroy();
	
	setcookie("user_id", "", time()-3600);
	setcookie("user_name", "", time()-3600);
	setcookie("user_type", "", time()-3600);
	setcookie("user_status", "", time()-3600);
	unset($_COOKIE['user_id']);	
	unset($_COOKIE['user_name']);	
	unset($_COOKIE['user_type']);	
	unset($_COOKIE['user_status']);	

    if (isset($_SESSION['user_id'])):
        session_regenerate_id();
        unset($_SESSION['user_id']);
        unset($_SESSION['user_type']);
        unset($_SESSION['user_name']);
        unset($_SESSION['user_status']);
        session_unset();
		
    endif;

    $_SESSION['logout']='yes';
	
    $msg = "You have logged out successfully.";
    setcookie("msg", $msg, time() + 3);
    header("location:http://localhost/innovins_interview/index.php");
?>
