<?php
    include("includes/connection.php");
    
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
    // ---------- Cookie Info ---------- //
	$cookie_name = 'innovins';
	$cookie_time = (3600 * 24 * 30); // 30 days
	//------------- AUTO LOGIN ----------------//
	if(isSet($cookie_name)){
		// Check if the cookie exists
		if(isSet($_COOKIE[$cookie_name])){
			parse_str($_COOKIE[$cookie_name],$output);

			extract($output);

			$_SESSION['user_name'] 	  = @$user_name;
			$_SESSION['user_type'] 	  = @$user_type;
			$_SESSION['user_status']  = @$user_status;
			$_SESSION['user_id']	  = @$user_id;
		}
	}

    if ($_POST && $_POST['csrf']== $_SESSION["token"]) {

    	$_SESSION['token'] = md5(uniqid(rand(), TRUE)); 

        $username = secure_inputs($_POST['user_name']);
        $password = md5(trim(secure_inputs($_POST['password'])));
        $res = query_data("select * from users where user_name='$username' ",'','S');
        $now = strtotime(date('Y-m-d H:i:s'));

        if(count_data($res) > 0){
        	$user_pass = $res->password;
        	$user_id = $res->id;
        	if($password===$user_pass) {
        		if ($res->user_name == $username && secure_inputs(trim($res->password)) == $password) {

            	//STORE USER INFORMATION INSESSION VARIABLE TO HAVE ACCESS TO THE INFORMATIONS IN OTHER PAGES... 
            	 $_SESSION['user_type'] = $res->user_type;
                 $_SESSION['user_id'] 	 = $res->id;
                 $_SESSION['user_status'] = $res->status;    
                  header("location:users_listing.php");
		        }               
            } else {
                $msg = "Invalid UserName/Password.";
               
                setcookie("msg", $msg, time() + 3);
                header("location:index.php");
                exit;
            }
        } else {
            $msg = "User does not exists.";            
            setcookie("msg", $msg, time() + 3);
            header("location:index.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>INNOVINS-LOGIN</title>
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		<link rel="shortcut icon" type="image/x-icon" href="<?=SITEURL?>assets/img/favicon.png">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/>assets/css/feather.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/style.css">
		<link rel="stylesheet" href="http://localhost/innovins_interview/assets/css/custom.css">
		<style>
			.login-wrapper .loginbox {border: 1px solid #e5e5e5; border-radius: 5px; -webkit-box-shadow: 0 10px 15px #e5e5e5; box-shadow: 0 10px 15px #e5e5e5;}
			.lgin{
				padding-top: 202px;
    padding-left: 68px;
    font-size: 68px;
			}
		</style>
	</head>
	<body>
		<div class="main-wrapper">
			<div class="header d-none">
				<ul class="nav nav-tabs user-menu">
					<li class="nav-item">
						<a href="#" id="dark-mode-toggle" class="dark-mode-toggle"><i class="feather-sun light-mode"></i><i class="feather-moon dark-mode"></i></a>
					</li>
				</ul>
			</div>
			<div class="row">
				<div class="col-md-6">
					
								
								<h4 class="lgin">INNOVINS LOGIN PAGE...</h4>
							
				</div>
				<div class="col-md-6 login-wrap-bg">
					<div class="login-wrapper">
						<div class="loginbox">
							<!-- <div class="img-logo">
								<img src="<?=SITEURL?>assets/img/logo_big.png" class="img-fluid" alt="Logo">
							</div> -->
							
							<p class="account-subtitle">login to your account to continue</p>
							<?php if (isset($_COOKIE['msg'])) { ?><center><span style="color:red;"><?php print str_replace("+", " ", $_COOKIE['msg']); ?></span></center><?php } ?>
							<?php if (isset($_COOKIE['error'])) { ?><center><span style="color:red;"><?php print str_replace("+", " ", $_COOKIE['error']); ?></span></center><?php } ?>
							<?php if (isset($_COOKIE['success'])) { ?><center><span style="color:green;"><?php print str_replace("+", " ", $_COOKIE['success']); ?></span></center><?php } ?>
							<form method="post">
								<div class="form-group form-focus">
									<input type="text" class="form-control floating" name="user_name" required>
									<label class="focus-label">Enter User Name</label>
								</div>
								<div class="form-group form-focus">
									<input type="password" class="form-control floating" name="password">
									<label class="focus-label">Enter Password</label>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-6">
											<a class="forgot-link" href="http://localhost/innovins_interview/add_users.php">New User? Sign Up</a>
										</div>
										<div class="col-6 text-end">
											<a class="forgot-link" href="http://localhost/innovins_interview/forgot_password.php">Forgot Password ?</a>
										</div>
									</div>
								</div>
								<div class="d-grid">
									<input type="hidden" name="csrf" value="<?=$_SESSION["token"];?>">
									<button class="btn btn-login" type="submit">Login</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- JS -->
		<script src="http://localhost/innovins_interview/assets/js/jquery-3.6.0.min.js"></script>
		<script src="http://localhost/innovins_interview/assets/js/bootstrap.bundle.min.js"></script>
		<script src="http://localhost/innovins_interview/assets/js/script.js"></script>
	</body>
</html>