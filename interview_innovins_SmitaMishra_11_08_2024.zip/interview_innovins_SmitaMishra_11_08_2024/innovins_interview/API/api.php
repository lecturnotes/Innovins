<?php
include("../includes/connection.php");
//  ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
//  error_reporting(E_ALL);
// API endpoint functions
function getProducts() {
    $query = "SELECT * FROM products";
    $result = db_connect()->query($query);
    if ($result->num_rows > 0) {
        $products = array();
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        return json_encode($products);
    } else {
        return json_encode(array("error" => "No products found"));
    }
}

function getProduct($id) {
    $query = "SELECT * FROM products WHERE id = '$id'";
    $result = db_connect()->query($query);
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        return json_encode($product);
    } else {
        return json_encode(array("error" => "Product not found"));
    }
}

function createProduct($name, $description, $price) {
    $query = "INSERT INTO products (name, description, price) VALUES ('$name', '$description', '$price')";
    if (db_connect()->query($query) === TRUE) {
        return json_encode(array("message" => "Product created successfully"));
    } else {
        return json_encode(array("error" => "Failed to create product"));
    }
}

function updateProduct($id, $name, $description, $price) {
    $query = "UPDATE products SET name = '$name', description = '$description', price = '$price' WHERE id = '$id'";
    if (db_connect()->query($query) === TRUE) {
        return json_encode(array("message" => "Product updated successfully"));
    } else {
        return json_encode(array("error" => "Failed to update product"));
    }
}

function deleteProduct($id) {
    $query = "DELETE FROM products WHERE id = '$id'";
    if (db_connect()->query($query) === TRUE) {
        return json_encode(array("message" => "Product deleted successfully"));
    } else {
        return json_encode(array("error" => "Failed to delete product"));
    }
}

// API endpoint routes
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        echo getProduct($_GET['id']);
    } else {
        echo getProducts();
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['name']) && isset($data['description']) && isset($data['price'])) {
        echo createProduct($data['name'], $data['description'], $data['price']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['id']) && isset($data['name']) && isset($data['description']) && isset($data['price'])) {
        echo updateProduct($data['id'], $data['name'], $data['description'], $data['price']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['id'])) {
        echo deleteProduct($data['id']);
    }
}

// Close the database connection
db_connect()->close();
?>