<?php 
	include("includes/connection.php");
    

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

	$page_name = 'Manage Users';
	$page_title = 'Manage Users';
	$return_url = "add_users.php";

	

	if (isset($_POST['add-users']) && $_POST['csrf']== $_SESSION["token"]) {
    	$_SESSION['token'] = md5(uniqid(rand(), TRUE));

		//print_result($_POST);exit;
		$data['user_name'] = $u_nm = secure_inputs($_POST['user_name']);
		$data['full_name'] = $_POST['full_name'];
		$data['phone'] = $_POST['phone'];
		$data['email'] = $_POST['email'];
		$data['user_type'] = $_POST['user_type'];
		$data['password'] = md5($_POST['password']);
		
		$chk = query_data("SELECT * FROM users where user_name='$u_nm'");
		if ($chk) {
			$msg = "User Name already exists.";
		    setcookie("error", $msg, time() + 3);
		    header("location:".$return_url);
		} else {
			$insertchk = insert_data('users',$data);
		    $last_id = $insertchk['insertid'];

		    $msg = 'Data Processed successfully.';
		    setcookie("success", $msg, time() + 3);
		    header("location:".$return_url);
		}
    }


	include("inc/top_head.php");
 
?>
	
<?php if (isset($_COOKIE['success'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-success">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['success']); ?>
	</div>
<?php } ?>
<?php if (isset($_COOKIE['error'])) { ?>
	<div class="clearfix"></div>	
	<div class="alert alert-danger">
		<a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
		<?php print str_replace("+", " ", $_COOKIE['error']); ?>
	</div>
<?php } ?>

<form method="post" action="http://localhost/innovins_interview/add_users.php">
	<div class="row">	
		<div class="col-sm-12">
			<div class="card">
				<div class="card-header">
					<div class="row mb-2 mt-2"> <!-- align-items-center -->
						<div class="col-md-4">
							<div class="row mb-2">
								<div class="col-3"><label>Full Name<span class="text-danger">*</span></label></div>
								<div class="col-8"  style="min-width: 250px;">
									<input type="text" class="form-control" name="full_name"  required autocomplete="off" maxlength="30" autofocus="autofocus">
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>Phone</label></div>				
								<div class="col-8" style="min-width: 250px;">
									<input type="text" class="form-control" name="phone" id="phone" autocomplete="off" onkeypress="return /[0-9]/i.test(event.key)" maxlength="10">
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>Email</label></div>				
								<div class="col-8" style="min-width: 250px;">			
									<input type="email" class="form-control" name="email" id="email" autocomplete="off" maxlength="50">
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row mb-2">
								<div class="col-3"><label>User Type<span class="text-danger">*</span></label></div>		
								<div class="col-8" style="min-width: 250px;">			
									<select class="form-select" name="user_type" required>
										<option value="">Select...</option>
										<option value="Admin">Admin</option>
										<option value="User">User</option>
										
									</select>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-3"><label>User Name<span class="text-danger">*</span></label></div>
								<div class="col-8"  style="min-width: 250px;">
									<input type="text" class="form-control" name="user_name"  required autocomplete="off" maxlength="20">
								</div>
							</div>
							<div class="row">
								<div class="col-3"><label>Password<span class="text-danger">*</span></label></div>
								<div class="col-8" style="min-width: 250px;">			
									<input type="password" class="form-control" name="password" id="password" autocomplete="off" maxlength="10">
								</div>
							</div>	
						</div>
									
					</div>	
				</div>
				<div class="card-body">							
					
					<div class="col-md-12">
						<div  style="text-align:center" class="">
							<input type="hidden" name="csrf" value="<?=$_SESSION["token"]?>">
							<button type="submit" class="btn btn-login" name="add-users">Save</button>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
</form>


</div> 
</div>	
</div>



<?php include("inc/js.php"); ?>

<script type="text/javascript">

	function checkAll(i) {
		var mod_id = $('#mst_mod_chk'+i).is(':checked');
		//console.log(mod_id);

		if (mod_id==true) {
			$('.mod-control-input'+i).prop('checked', true);
			$('#mst_view'+i).val(1);
			$('#mst_edit'+i).val(1);
			$('#mst_del'+i).val(1);
		} else {
			$('#mst_view'+i).val(0);
			$('#mst_edit'+i).val(0);
			$('#mst_del'+i).val(0);
			$('.mod-control-input'+i).prop('checked', false);
		}
	}
</script>
</body>
</html>