<?php
include("includes/connection.php");
//  ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
//  error_reporting(E_ALL);

$page_name = 'Manage Users';
$subpage_name = '';
$page_title = 'Manage Users';

$session_id = $_SESSION['user_id'];

//echo $session_id;
$chk_session_qry = db_query("SELECT user_type FROM users WHERE id='$session_id'");
$rslt = mysqli_fetch_object($chk_session_qry);
$utyp = $rslt->user_type;

if($utyp == 'Admin'){
$res = query_data("SELECT * FROM users WHERE status=1 ORDER BY id DESC");// WHERE status=1
}
elseif($utyp == 'User'){
$res = query_data("SELECT * FROM users WHERE id='$session_id' ORDER BY id DESC");
}

if (isset($_GET['val']) && $_GET['val'] != "" && isset($_GET['id']) && $_GET['id'] != "" && isset($_GET['tbl']) && $_GET['tbl'] != "") {
    $status = $_GET['val'];
    $id = $_GET['id'];
    $table_name = $_GET['tbl'];

    if ($status == 1) {
        $data['status'] = $status = 0;
    } else if ($status == 0) {
        $data['status'] = $status = 1;
    }

    $updatechk = update_data($table_name, $data, array('id' => $id));
    //var_dump($updatechk);
    exit();
}

/* Delete medicine*/
if (isset($_GET['delid'])) {
    $delid = secure_inputs($_GET['delid']);
    if ($delid != "") {
        $delchk = delete_data("users", array('id' => $delid));
        if ($delchk) {
            if ($delchk['affectrow'] > 0) {
                $msg = $delchk['message'];
                setcookie("success", $msg, time() + 3);
                header("location:users_listing.php");
            } else {
                $msg = $delchk['message'];
                setcookie("error", $msg, time() + 3);
                header("location:users_listing.php");
            }
        } else {
            $msg = $delchk['message'];
            setcookie("error", $msg, time() + 3);
            header("location:user_listing.php");
        }
    }
}


include("inc/top_head.php");
?>
<style type="text/css">
    .remove {
        margin-left: 71px;
    }

    .medicines_detail {
        max-width: 1500px;
    }
</style>

<div class="row">
    <div class="col-md-12">
        <?php if (isset($_COOKIE['success'])) { ?>
            <div class="clearfix"></div>
            <div class="alert alert-success">
                <a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
                <?php print str_replace("+", " ", $_COOKIE['success']); ?>
            </div>
        <?php } ?>
        <?php if (isset($_COOKIE['error'])) { ?>
            <div class="clearfix"></div>
            <div class="alert alert-danger">
                <a href="javascript:void(0)" class="close" data-dismiss="alert" onClick="$('.alert').hide('slow');">&times;</a>
                <?php print str_replace("+", " ", $_COOKIE['error']); ?>
            </div>
        <?php } ?>
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="doc-badge me-3"><h4>User List</h4></div>
                    </div>
                    <div class="col-auto custom-list d-flex">
                        <div class="dt-buttons btn-group btn-group2">
                            <a class="btn btn-secondary" href="http://localhost/innovins_interview/add_users.php"><i
                                        class="feather-file-plus"></i> Add User </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="row align-items-center mb-2 mt-2">
                    <div class="col-auto me-auto">
                        <div class="form-custom">
                            <div id="tableSearch" class="dataTables_wrapper"></div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="datatable table table-borderless hover-table" id="sort-data-table">
                        <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Full Name</th>
                            <th>User Name</th>
                            <th>User Type</th>
                            <th>Email</th>
                             
                            
                            <th class="text-end">Edit Action</th>
                            <th class="text-end">Reset Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 0;
                        if ($res) {
                            foreach ($res as $r) {
                                $i++;
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $r->full_name ?></td>
                                    <td><?= $r->user_name ?></td>
                                    <td><?= $r->user_type ?></td>
                                   <td><?= $r->email ?></td>
                                    
                                   <?php if($utyp == 'Admin'){?>
                                    <td class="text-end action">
                                        <a href="http://localhost/innovins_interview/edit_users.php?id=<?= $r->id ?>"><i
                                                    class="fa fa-edit"></i></a>
                                        <a href="http://localhost/innovins_interview/users_listing.php?delid=<?= $r->id ?>"><i class="fa fa-trash" ></i></a>
                                    </td>
                                <?php }else{?>
                                    <td class="text-end action">
                                        <a href="http://localhost/innovins_interview/edit_users.php?id=<?= $r->id ?>"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <?php }?>
                                    <td class="text-end">
                                        <a href="http://localhost/innovins_interview/reset_password.php?id=<?= $r->id ?>"
                                           class="btn btn-sm btn-success" type="button">Reset Password</a>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
</div>
</div>
</div>
</div>

<?php include("inc/js.php"); ?>


</body>
</html>